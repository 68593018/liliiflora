package com.example.dictionary.spi.api;

public interface Dictionary {
    String getDefinition(String word);
}
