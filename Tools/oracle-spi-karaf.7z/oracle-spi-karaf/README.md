# oracle-spi-karaf

SPI如何集成到Karaf容器中

## 问题背景

前期在做ODL的数据库兼容工作的过程中，计划将ODL的存储适配到第三方数据库EtcdV3中，一方面可以验证替换ODL原始数据库的可行性，另一方面可以降低数据库的代码维护工作。

在各项前期准备工作完成后，开始将写好的代码集成到ODL的Karaf环境中，采用jetcd连接Etcd服务端的时候出现了以下异常打印

    No functional channel service provider found Try adding a dependency on the grpc-okhttp or grpc-netty artifact

以上打印由grpc项目的ManagedChannelProvider输出，经过分析，此现象和一种叫SPI的机制有关系

## SPI简介

SPI可以参考以下链接, 里面有SPI的详细介绍，并且有一个示例对SPI的机制进行了完整的描述，该示例代码已经简化到oracle-spi中

[http://www.oracle.com/technetwork/articles/javase/extensible-137159.html#](http://www.oracle.com/technetwork/articles/javase/extensible-137159.html# "oracle-spi")

简单来说，SPI是一个接口或者抽象类，具体的实现由第三方服务商提供，SPI实现提供者在所在的jar包中META-INF/services目录下创建
以SPI命名的文件，并且在文件内容中填写具体的SPI实现类名

SPI服务消费者通过java.util.ServiceLoader的load方法，并且提供SPI的名称，获取所有的SPI实现者，从而可以得到SPI提供者的服务


## OSGI环境下SPI问题

由于java.util.ServiceLoader的load方法是通过遍历所有jar包里面的META-INF/services的配置文件，并且通过当前线程的ClassLoader去加载配置文件中的SPI实现类，从而完成load过程。

但是在OSGI环境下，各个jar包实际被封装成bundle, 每个bundle都有自己的ClassLoader，该ClassLoader只能加载当前bundle下的类，所以消费者的bundle是无法通过load获取服务提供者bundle的SPI实现类

## OSGI环境下SPI解决

OSGI针对SPI的这种情况提供了如下解决方案，提供了spifly进行支持

bundle:install mvn:org.apache.aries.spifly/org.apache.aries.spifly.dynamic.bundle/1.0.8

OSGI下SPI解决方案：

[http://blog.osgi.org/2013/02/javautilserviceloader-in-osgi.html](http://blog.osgi.org/2013/02/javautilserviceloader-in-osgi.html "osgi spi blog")

OSGI下SPI官方文档:

[http://aries.apache.org/modules/spi-fly.html#usage](http://aries.apache.org/modules/spi-fly.html#usage "spi-fly")


## 备注

oracle-spi提供了非OSGI环境下的SPI示例，oracle-spi-karaf提供了OSGI容器下的SPI示例，可以通过比较两个项目的pom配置文件即可看出区别

oracle-spi-blueprint-demo项目以blueprint方式加载，目前无法正常使用上述spifly的解决方案，还在研究中......

