package com.example.dictionary.service;

import com.example.dictionary.spi.api.Dictionary;

import com.example.dictionary.service.DictionaryService;
import javax.swing.JOptionPane;

public class DictionaryUser extends javax.swing.JFrame {

    /** Creates new form DictionaryUser */
    public DictionaryUser() {
        dictionary = DictionaryService.getInstance();
        //initComponents();
    }

    /** This method is called from within the constructor to
     * initialize the form.
     */
    private void initComponents() {
        // ...
        txtWord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtWordActionPerformed(evt);
            }
        });
        // ...
    }

    private void txtWordActionPerformed(java.awt.event.ActionEvent evt) {
        String searchText = txtWord.getText();
        String definition = dictionary.getDefinition(searchText);
        txtDefinition.setText(definition);
        if (definition == null) {
            JOptionPane.showMessageDialog(this,
            "Word not found in dictionary set",
            "Oops", JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new DictionaryUser().setVisible(true);
            }
        });*/
        DictionaryService dictionary = DictionaryService.getInstance();
        String bookDefinition = dictionary.getDefinition("book");
        System.out.println("book:");
        System.out.println(bookDefinition);

        String xmlDefinition = dictionary.getDefinition("XML");
        System.out.println("XML:");
        System.out.println(xmlDefinition);

    }
    // Variables declaration - do not modify
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblDefinition;
    private javax.swing.JLabel lblSearch;
    private javax.swing.JTextArea txtDefinition;
    private javax.swing.JTextField txtWord;
    // End of variables declaration
    private DictionaryService dictionary;
}
