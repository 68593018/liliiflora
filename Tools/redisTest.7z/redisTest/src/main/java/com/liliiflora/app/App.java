package com.liliiflora.app;

import java.lang.Integer;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Pipeline;
import redis.clients.jedis.Protocol;

/**
 * Hello world!
 *
 */
public class App 
{

    public static void main( String[] args )
    {
        System.out.println( "Hello World!!!" );
        int max_num = 0;
        max_num = Integer.parseInt(args[0]);

        Jedis jedis = new Jedis("192.168.1.4", 6379);
        jedis.connect();
        Pipeline p = jedis.pipelined();

        int i = 0;
        long start = System.currentTimeMillis(); 
        long end =0;
        try {


            while (i < max_num) {
                p.set("Test" + i, i + "");
                i++;
            }
            
        } finally {

            end = System.currentTimeMillis();
            p.sync();
            jedis.close();
        }
        

        System.out.println("reids op Pipeline :" + i + "times in " +  (end - start) + "msec");
    }


/*
    public static void main( String[] args )
    {
        System.out.println( "Hello World!!!" );
        int max_num = 0;
        max_num = Integer.parseInt(args[0]);

        Jedis jedis = new Jedis("192.168.1.4", 6379); 
        // jedis.auth("password");
        int i = 0;
        long start = System.currentTimeMillis(); 
        long end =0;
        try {


            while (i < max_num) {
                jedis.set("Test" + i, i + "");
                i++;
            }
            
        } finally {

            end = System.currentTimeMillis();
            jedis.close();
        }

        System.out.println("reids op:" + i + "times in " +  (end - start) + "msec");
    }
    */
    
}
